import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="datathon"
)

mycursor = mydb.cursor()

sql = "DROP TABLE temp "
mycursor.execute(sql) 

mycursor.execute("CREATE TABLE temp ( id DATE, persentage float ); ")


mycursor.execute("SELECT TOTAL FROM inbound WHERE date = '2022-01-01';")
myresult22 = mycursor.fetchone()[0]

mycursor.execute("SELECT TOTAL FROM inbound WHERE date = '2021-01-01';")
myresult21 = mycursor.fetchone()[0]

percent_change = ((myresult22 - myresult21) / myresult21) * 100

sql = "INSERT INTO temp2 (id, persentaze) VALUES (%s, %s)"
val = (1, percent_change)



mycursor.execute(sql, val)

mydb.commit()


